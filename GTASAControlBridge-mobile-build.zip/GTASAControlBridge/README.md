# GTA SA Control Bridge (Android starter project)

A small Android project for testing whether USB-OTG keyboard and mouse input is detected by the phone. **This is not yet a GTA San Andreas control mapper** and does not inject touch events into the game.

## Build the APK without a computer (cloud build)

This project includes `.github/workflows/build-apk.yml` for a cloud build. A GitHub account and uploading this project to a GitHub repository are required; no local Android SDK is needed.

1. Download and extract this ZIP on your phone.
2. In your mobile browser, open GitHub and create a new repository (for example, `GTASAControlBridge`).
3. Upload the extracted project files and folders to the repository, keeping `.github/workflows/build-apk.yml` in that exact path. GitHub's web upload may be awkward on mobile; if it hides dot-folders, use a repository upload method that preserves `.github`.
4. Open the repository's **Actions** tab and choose **Build Android APK**. Tap **Run workflow** if it has not started automatically.
5. When the run finishes successfully, open that run and download the `GTASAControlBridge-debug-apk` artifact.
6. Extract the downloaded artifact ZIP; it contains `app-debug.apk`. Tap it to install. Android may ask you to allow installs from the browser/files app.

## Local build (computer)

Use JDK 17, Android SDK Platform 35, and Gradle 8.9. From this project folder run `gradle assembleDebug`. The APK output is `app/build/outputs/apk/debug/app-debug.apk`.

## Test

Connect a USB-OTG keyboard and mouse, open the app, and press W/A/S/D, Space or move/click the mouse. Events visible while this app is in the foreground should appear in the log.

## Important limitations

- This prototype tests hardware input while its own screen is open.
- The accessibility service passes keys through and does not control other apps.
- It does not yet map keyboard/mouse inputs to GTA SA touch controls. That requires a separate overlay/calibration design, explicit user-granted permissions, and testing against the specific GTA SA release installed on the phone.
- The APK has not been built or device-tested in this environment.
