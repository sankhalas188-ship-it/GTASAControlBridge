package com.example.gtasacontrolbridge

import android.accessibilityservice.AccessibilityService
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/** Optional starter service. This version intentionally observes no game content and does not inject input. */
class InputAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit
    override fun onKeyEvent(event: KeyEvent): Boolean {
        // Pass keys through unchanged. Future mapping should be added only after testing game compatibility.
        return false
    }
}
