package com.example.gtasacontrolbridge

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var log: TextView
    private val entries = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }
        root.addView(TextView(this).apply {
            text = "GTA SA Control Bridge"
            textSize = 25f
        })
        root.addView(TextView(this).apply {
            text = "Prototype 0.1 • USB OTG input test"
            textSize = 15f
            setPadding(0, 8, 0, 18)
        })
        status = TextView(this).apply {
            text = "Connect your USB OTG keyboard/mouse, then tap this screen and test keys."
            textSize = 16f
            setPadding(0, 0, 0, 16)
        }
        root.addView(status)
        root.addView(Button(this).apply {
            text = "Open Accessibility Settings (optional)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(TextView(this).apply {
            text = "Local input test"
            textSize = 18f
            setPadding(0, 20, 0, 6)
        })
        root.addView(TextView(this).apply {
            text = "Press W, A, S, D, Space or move/click the mouse while this screen is open. Events seen here will appear below."
            textSize = 14f
        })
        log = TextView(this).apply { textSize = 14f; setPadding(0, 12, 0, 12) }
        val scroll = ScrollView(this)
        scroll.addView(log)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(Button(this).apply {
            text = "Clear log"
            setOnClickListener { entries.clear(); refreshLog() }
        })
        setContentView(root)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val source = InputDevice.getDevice(event.deviceId)?.name ?: "Unknown device"
        addLog("KEY ${KeyEvent.keyCodeToString(event.keyCode)} ${if (event.action == KeyEvent.ACTION_DOWN) "DOWN" else "UP"} • $source")
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        val source = InputDevice.getDevice(event.deviceId)?.name ?: "Unknown device"
        when (event.action) {
            MotionEvent.ACTION_HOVER_MOVE -> addLog("MOUSE MOVE x=${event.x.toInt()} y=${event.y.toInt()} • $source")
            MotionEvent.ACTION_SCROLL -> addLog("MOUSE SCROLL • $source")
            MotionEvent.ACTION_BUTTON_PRESS -> addLog("MOUSE BUTTON PRESS • $source")
            MotionEvent.ACTION_BUTTON_RELEASE -> addLog("MOUSE BUTTON RELEASE • $source")
        }
        return super.dispatchGenericMotionEvent(event)
    }

    private fun addLog(line: String) {
        entries.add(0, line)
        if (entries.size > 35) entries.removeAt(entries.lastIndex)
        refreshLog()
    }

    private fun refreshLog() { log.text = entries.joinToString("\n") }
}
